#!/bin/bash

DIRNAME=`dirname $0`
PLATFORM=$(uname)
#PWD = `pwd`

cd $DIRNAME
source /etc/profile
MV_CAM_SDK_PATH_OLD=$MVCAM_SDK_PATH

ARCH=$(uname -m)
if [ ${ARCH} = "aarch64" ]; then
	if grep -q "rk3588" /proc/device-tree/compatible &> /dev/null; then
        PLATFORM="rk3588"
	fi
fi

if [ ! -n "${MV_CAM_SDK_PATH_OLD}" ]; then
if [ ${PLATFORM} != "rk3588" ]; then
	read -p "Please Input Install Path, Default Path is [/opt]: " InstallPath
	echo -e "\n"
else
	InstallPath=/opt
fi

if [ ! -n "${InstallPath}" ]; then
	InstallPath=/opt
fi

echo "The install path is:$InstallPath"
#sed -i "s/export LD_LIBRARY_PATH/#export LD_LIBRARY_PATH/g" ~/.bashrc
source ~/.bashrc
if [ ! -d "${InstallPath}" ]; then
	mkdir -p ${InstallPath}
fi
if [ ! -d "${InstallPath}/MvCamCtrlSDK" ]; then
	echo "Install MvCamCtrlSDK, Please wait..."
	tar -C ${InstallPath} -xzf ./MvCamCtrlSDK_Runtime.tar.gz
else
	echo "Uninstall MvCamCtrlSDK, Please wait..."
	rm -rf ${InstallPath}/MvCamCtrlSDK
	echo "Install MvCamCtrlSDK, Please wait..."
	tar -C ${InstallPath} -xzf ./MvCamCtrlSDK_Runtime.tar.gz
fi
CONFIG_NAME=$(sed 's#.*/##' ./Config.ini | tr -d '\r\n')
else
	echo "Already install MvCamCtrlSDK in ${MV_CAM_SDK_PATH_OLD}, Install New MvCamCtrlSDK, Please wait..."
	tar -xzf ./MvCamCtrlSDK_Runtime.tar.gz
if [ -d "${MV_CAM_SDK_PATH_OLD}/logserver" ]; then
	rm -rf ${MV_CAM_SDK_PATH_OLD}/logserver
fi
if [ -d "${MV_CAM_SDK_PATH_OLD}/driver" ]; then
	rm -rf ${MV_CAM_SDK_PATH_OLD}/driver
fi
if [ -d "${MV_CAM_SDK_PATH_OLD}/lib" ]; then
	rm -rf ${MV_CAM_SDK_PATH_OLD}/lib
fi
if [ -d "${MV_CAM_SDK_PATH_OLD}/license" ]; then
	rm -rf ${MV_CAM_SDK_PATH_OLD}/license
fi
if [ -e "${MV_CAM_SDK_PATH_OLD}/ReleaseNote_CH.txt" ]; then
	rm -rf ${MV_CAM_SDK_PATH_OLD}/ReleaseNote*
fi
	if [ ${PLATFORM} != "rk3588" ]; then
		read -p "Please Input Install Path, Default Path is [/opt]: " InstallPath
		echo -e "\n"
	else
		InstallPath=/opt
	fi
	if [ ! -n "${InstallPath}" ]; then
		InstallPath=/opt
	fi
	echo "The install path is:$InstallPath"

	CONFIG_NAME=$(sed 's#.*/##' ./Config.ini | tr -d '\r\n')

if [ ! -d "${InstallPath}/${CONFIG_NAME}" ]; then
	mkdir -p ${InstallPath}/${CONFIG_NAME}
fi
	if [ -d "${InstallPath}/${CONFIG_NAME}/logserver" ]; then
		rm -rf ${InstallPath}/${CONFIG_NAME}/logserver
	fi
	if [ -d "${InstallPath}/${CONFIG_NAME}/driver" ]; then
		rm -rf ${InstallPath}/${CONFIG_NAME}/driver
	fi
	if [ -d "${InstallPath}/${CONFIG_NAME}/lib" ]; then
		rm -rf ${InstallPath}/${CONFIG_NAME}/lib
	fi
	if [ -d "${InstallPath}/${CONFIG_NAME}/license" ]; then
		rm -rf ${InstallPath}/${CONFIG_NAME}/license
	fi

	mv MvCamCtrlSDK/logserver ${InstallPath}/${CONFIG_NAME}
	mv MvCamCtrlSDK/driver ${InstallPath}/${CONFIG_NAME}
	mv MvCamCtrlSDK/lib ${InstallPath}/${CONFIG_NAME}
	mv MvCamCtrlSDK/license ${InstallPath}/${CONFIG_NAME}

	if [ -e MvCamCtrlSDK/ReleaseNote_CH.txt ]; then
		mv MvCamCtrlSDK/ReleaseNote* ${InstallPath}/${CONFIG_NAME}
	fi

	if [ -d "./MvCamCtrlSDK" ]; then
		rm -rf ./MvCamCtrlSDK
	fi
fi

#Runtime包安装路径默认与软件相同
if [ -d "${InstallPath}/MvCamCtrlSDK" ]; then
	mv ${InstallPath}/MvCamCtrlSDK ${InstallPath}/${CONFIG_NAME}
fi

#非rk3588平台需要删除采集卡相关库及驱动
if [ ${PLATFORM} != "rk3588" ]; then
	rm ${InstallPath}/${CONFIG_NAME}/driver/pcie -rf
	rm ${InstallPath}/${CONFIG_NAME}/lib/aarch64/libMVFGControl.so
	rm ${InstallPath}/${CONFIG_NAME}/lib/aarch64/MvFGProducer*.cti
	rm ${InstallPath}/${CONFIG_NAME}/lib/aarch64/libCLSerHvc.so
else #rk3588平台增加相关pcie驱动启动
	if [ -f ${InstallPath}/${CONFIG_NAME}/driver/pcie/unload.sh ]; then
		bash ${InstallPath}/${CONFIG_NAME}/driver/pcie/unload.sh
	fi
	if [ -f ${InstallPath}/${CONFIG_NAME}/driver/pcie/build.sh ]; then
    	sh ${InstallPath}/${CONFIG_NAME}/driver/pcie/build.sh 
	fi
	if [ -f ${InstallPath}/${CONFIG_NAME}/driver/pcie/load.sh ]; then
    	sh ${InstallPath}/${CONFIG_NAME}/driver/pcie/load.sh 
	fi
fi

#source ~/.bashrc

echo "Set up the SDK environment..."
if [ ${PLATFORM} != "rk3588" ]; then
	bash $DIRNAME/set_usb_priority.sh
fi
bash $DIRNAME/set_virtualserial_priority.sh

if [ -d "${InstallPath}/${CONFIG_NAME}" ]; then
source $DIRNAME/set_env_path.sh ${InstallPath}/${CONFIG_NAME}
echo "source $DIRNAME/set_env_path.sh ${InstallPath}/${CONFIG_NAME}"
if [ -f ${InstallPath}/${CONFIG_NAME}/driver/gige/unload.sh ]; then
	bash ${InstallPath}/${CONFIG_NAME}/driver/gige/unload.sh
fi
if [ -f ${InstallPath}/${CONFIG_NAME}/driver/gige/driver_self_starting.sh ]; then
    ${InstallPath}/${CONFIG_NAME}/driver/gige/driver_self_starting.sh 1
fi
if [ ${PLATFORM} != "rk3588" ]; then
	if [ -f script_self_starting.sh ]; then
    	./script_self_starting.sh 1
	fi
fi
cd ${InstallPath}/${CONFIG_NAME}/logserver
./RemoveServer.sh
./InstallServer.sh
fi

if [ ${PLATFORM} = "rk3588" ]; then
	if grep -q "sva2500" /etc/os-release; then 
		#虚拟网卡管理脚本
		if [ -f "${InstallPath}/${CONFIG_NAME}/driver/pcie/S91ManageVirnic" ]; then
			mv ${InstallPath}/${CONFIG_NAME}/driver/pcie/S91ManageVirnic /etc/init.d/S91ManageVirnic
			chmod 777 /etc/init.d/S91ManageVirnic
			/etc/init.d/S91ManageVirnic restart
		fi
	fi
fi

cd -

echo "Install MvCamCtrlSDK complete!"
echo "Tips: You should be launch a new terminal or execute source command for the bash environment!"
cd $PWD



